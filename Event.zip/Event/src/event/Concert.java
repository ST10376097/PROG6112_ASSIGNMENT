/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package event;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Admin
 */

//child class
public class Concert extends Prom {
    //all attributes and methods from prom class will be read here to
    
  
    public Concert(String name, String food, String beverage) {
        super(name, food, beverage);
       
    }

   @Override
   public void User_Input()
    {
       super.User_Input();
    }
   
    @Override
   public void exitProgram()
   {
       super.exitProgram();
   }
}
    
    
    

  