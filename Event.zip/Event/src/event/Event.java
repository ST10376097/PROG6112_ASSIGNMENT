/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package event;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Admin
 */
public class Event {
  
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
     //school wants to host an event --> program to allow students to choose which event they prefer.
     //each student must choose the meal & drink  they prefer for the chosen event.
        Scanner kb = new Scanner(System.in);
        
        System.out.println("*****SCHOOL EVENT*****");
        
    //declare and initialize variables
    String name = "";
    String food = "";
    String beverage = "";
 
        //event menu
        System.out.println("""
                           Enter the event you prefer: 
                           1 -> Concert 
                           2 -> Prom""");
        int option = kb.nextInt();
      Concert con = new Concert(name, food, beverage);
      Prom prom = new Prom(name, food, beverage);
      
        switch(option)
        {
           
            case 1: 
               
               //call method to get user input
                con.User_Input();
                
                 //display details
                System.out.println("\n****DETAILS****");
                System.out.println("\nEvent chosen: CONCERT ");
                 System.out.println("Name: " + con.getName());
                 System.out.println("Meal: " + con.getFood());
                 System.out.println("Drink: " + con.getBeverage());
               
                 break;
   
            case 2:
              
               prom.User_Input();
             
                //display details
                System.out.println("\n****DETAILS****");
                
                System.out.println("\nEvent chosen: PROM " );
                System.out.println("Name: " + prom.getName());
                 System.out.println("Meal: " + prom.getFood());
                 System.out.println("Drink: " + prom.getBeverage());
               break;
             
        }
        
       
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
//    public static void Concert_Event()
//    {
//        
//        
//        int numGuests;
//        Concert con = new Concert();
//        Scanner input = new Scanner(System.in);
//        System.out.println("Enter the number of  guests for the concert >>");
//        
//        numGuests = input.nextInt();
//        
//        con.setNumGuests(con.numGuests);//guests variable is private, hence setter to assign value
//        
//        System.out.println("The party has " + con.getNumGuests() + "guests");
//        myParty.displayInvitation();
//    }
//    
//    //now for option 2
//    public static void Prom_Event()
//    {
//        int choice, guests;
//        DinnerParty dp = new DinnerParty();
//        Scanner input = new Scanner(System.in); 
//        
//        System.out.println("Enter the number of guests for the party >>");
//        guests = input.nextInt();
//        
//        //set values for the respective class you working with
//        dp.setGuests(guests);
//        
//        System.out.println("Enter the menu option -->1 for chicken or -->2 for beef");
//      choice = input.nextInt();
//        
//        dp.setDinnerChoice(choice);
//        
//        String option = "";
//        if(dp.getDinnerChoice() == 1){
//            option = "Chicken";
//        }
//        else
//        {
//            option = "beef";
//        }
//        
//        System.out.println("The dinner party has " + dp.getDinnerChoice());
//        System.out.println("Menu choice " + dp.getDinnerChoice() + "will be served");
//        dp.displayInvitation();
//    }
//}
//
//}
//
//    
//    
}
