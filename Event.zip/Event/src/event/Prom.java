/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package event;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
//parent class
public class Prom   {
    
   private String name;
   private String food;    
   private String beverage;
   private int index = 0;

    public Prom(String name, String food, String beverage) {
        this.name = name;
        this.food = food;
        this.beverage = beverage;
    }

    public String getName() {
        return name;
    }

    public String getFood() {
        return food;
    }

    public String getBeverage() {
        return beverage;
    }

  
    public void User_Input()
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter your name >>");
       name = input.nextLine();
        
        System.out.println("""
                           What type of meal would you like? 
                           1 -> Burger & Chips 
                           2 -> Pizza 
                           3 -> Pasta
                           """);
     //save user input to food var here from prom class
        int choice = input.nextInt();
        input.nextLine(); //newline character

        switch (choice) {
            case 1:
                food = "Burger & Chips";
                break;
            case 2:
                food = "Pizza";
                break;
            case 3:
                food = "Pasta";
                break;
            default:
                System.out.println("Invalid choice!");break;
        }

        index++;
        
        System.out.println("Enter the type of beverage you would like >> \n"
                + "1 -> Soda\n"
                + "2 -> Iced Tea \n"
                + "3 -> Juice");
        
        int option = input.nextInt();
        input.nextLine(); //newline character
        
         switch (option) {
            case 1:
                this.beverage = "Soda";
                break;
            case 2:
               this.beverage = "Iced Tea";
                break;
            case 3:
               this.beverage = "Juice";
                break;
            default:
                System.out.println("Invalid choice!");break;
        }

        index++;
        
        
    }
    
    public void exitProgram()
    {
        System.out.println("Thank you!");
    }
    
  

    
}