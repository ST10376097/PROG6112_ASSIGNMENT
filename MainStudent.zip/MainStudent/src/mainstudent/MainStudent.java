/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mainstudent;

import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class MainStudent {

    /**
     * @param args the command line arguments
     */
    // this class contains the TWO MENUS
    public static void main(String[] args) {
        
        //menu ONE 
        //allow user input
        int option = Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                        STUDENT MANAGEMENT APPLICATION 
                                                                        \t\t**************************************************
                                                                        Enter (1) to launch menu or any other key to exit"""));
        
        //create main menu --> use switch case           
        switch(option)
        {
            case 1:Student_Menu();break;   
            default :JOptionPane.showMessageDialog(null, "Exiting the program");System.exit(0);
        }
        
           
    
    }
    
    //menu TWO
    public static void Student_Menu()
    {
        Student st = new Student();
        boolean invalid = true;
         
        while(invalid){
        int select = Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                        Please select one of the following menu items 
                                                                        (1) Capture a new student 
                                                                        (2) Search for a student 
                                                                        (3) Delete a student 
                                                                        (4) Print student report 
                                                                        (5) Exit Application"""));
         
       
        
        switch(select)
        {
            
           
            case 1: st.SaveStudent();break; //save student method
            case 2: st.SearchStudent();break;//search method 
            case 3: st.DeleteStudent();break;//delete method
            case 4: st.StudentReport();break;//report method
            case 5: st.ExitStudentApplication();break;//exit method
            default: JOptionPane.showMessageDialog(null, "Incorrect option selected, please select a number from (1-5)");break;
        }
       
    }
  }
}
