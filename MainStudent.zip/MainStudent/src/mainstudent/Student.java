/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainstudent;

import java.util.Arrays;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Admin
 */
public class Student {
    
    //this class contains all methods and their functions
    //will be called in the main
    
  //declare arrays
         public int SIZE;
         public int[] studentNum;
         public int[] studentID ;
         public String[] studentName;
         public int[] studentAge;
         public String[] studentEmail;
         public String[] studentCourse;

   

      //capture all student details in savestudent method
      public void SaveStudent()
   {
       
     
        //prompt user for the number of students to capture
        SIZE = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of students."));
         
        //captures details according to number of students
        studentNum = new int[SIZE];
        studentID = new int[SIZE];
        studentName = new String[SIZE];
        studentAge = new int[SIZE];
        studentEmail = new String[SIZE];
        studentCourse = new String[SIZE];
        
     
        
        //repeat for each student
          for (int i = 0; i < SIZE; i++){
           
        //prompts user for all details in one pop-up window
        JPanel panel = new JPanel();
        
        //for a vertical layout
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        
        JTextField ID = new JTextField(4);
        JTextField name = new JTextField(15);
        JTextField age = new JTextField(3);
        JTextField email = new JTextField(18);
        JTextField course = new JTextField(5);
        
        //user enters all details
        panel.add(new JLabel("Enter the student ID"));
        panel.add(ID);
        panel.add(new JLabel("Enter the student name:"));
        panel.add(name);
        panel.add(new JLabel("Enter the student age:"));
        panel.add(age);
         
        panel.add(new JLabel("Enter the student email:"));
        panel.add(email);
        panel.add(new JLabel("Enter the student course:"));
        panel.add(course);
        
        
        int result = JOptionPane.showConfirmDialog(null, panel, """
                                                                CAPTURE A NEW STUDENT  
                                                                
                                                                """, JOptionPane.OK_CANCEL_OPTION);
        
        if (result == JOptionPane.OK_OPTION){
            //autogenerate student number
             studentNum[i] = i + 1;
           //store the details in the arrays
           studentID[i] = Integer.parseInt(ID.getText()); 
           studentName[i] = name.getText();
           studentEmail[i] = email.getText();
           studentCourse[i]= course.getText();
           
           studentAge[i] = Integer.parseInt(age.getText()); 
         
         //invalid student age --> condition to be met
       
          while(studentAge[i] < 16){
            
                studentAge[i] = Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                                    \t\t <<<You have entered an incorrect student age!!>>> 
                                                                                     
                                                                                       please re-enter the student age >>"""));
                 
               }
             
          
              
      }
        
        }
          //succesfully saved message to be displayed at the end --> once all students details are saved
          JOptionPane.showMessageDialog(null, "student details have been succussfully saved! \n"
                  + "Thank You :)");
        
    }
      
   //method to search for a student 
      public void SearchStudent(){
        
      //User must enter the student id to search for a student
       int searchID = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the student ID to search:")); 
       int i = 0;
       boolean found = false;
        
       //iterates through student id array
         while(i < studentID.length){
             //if the id exists/is found --> display all details of student
             if(studentID[i] == searchID){
              
           
                   JOptionPane.showMessageDialog(null, "STUDENT ID: " +studentID[i] + "\n"
                        + "STUDENT NAME: " + studentName[i] + "\n"
                        + "STUDENT AGE: " + studentAge[i] + "\n"
                        + "STUDENT EMAIL: " + studentEmail[i]+ "\n"
                        + "STUDENT COURSE: " + studentCourse[i]);
                   
               found = true;
               break;
                }
             i++;
           }
       //if the id does not exist/cannot be found --> display 'not found message'
           if(!found)
           {
               JOptionPane.showMessageDialog(null, "Student with student ID: " + " " + searchID + " " + "was not found!");
           }
       
      
}
      
      //method to allow user to delete a saved student from the system
      public void DeleteStudent(){
          
          int i = 0; //initialize
          boolean found = false;
          
          //prompt user for the student ID to delete
          int deleteID = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the student ID to delete:"));
          
          
        
         //iterates through student id array
          while(i < studentID.length){
              //if the id exists/is found --> delete all student details & confirm deletion
              if(studentID[i] == deleteID){
                  found = true;
                  
                  //confirmation to delete
                   String confirm = JOptionPane.showInputDialog(null, "Are you sure you want to delete student " + deleteID + " " + "from the system? \n"
                  + "Yes --> (y) to delete.");
           
                  
                  
                  if(confirm.equals("y")){
                      JOptionPane.showMessageDialog(null, "Confirmed!");
                  for (int j = i; j < studentID.length -1; j++) {
                      //shift values in each array
                      studentID[j] = studentID[j + 1];
                      studentName[j] = studentName[j + 1];
                      studentAge[j] = studentAge[j + 1];
                      studentEmail[j] = studentEmail[j + 1];
                      studentCourse[j] = studentCourse[j+1];
                      
                      
                  }
                  //removing all details of the student chosen
                  studentID = Arrays.copyOf(studentID, studentID.length - 1);
                  studentName = Arrays.copyOf(studentName, studentName.length - 1);
                  studentAge = Arrays.copyOf(studentAge, studentAge.length - 1);
                  studentEmail = Arrays.copyOf(studentEmail, studentEmail.length - 1);
                  studentCourse = Arrays.copyOf(studentCourse, studentCourse.length - 1);
                  
                  
                  //student deleted message
                  JOptionPane.showMessageDialog(null, "Student with student ID:  " + deleteID + " " + "was deleted! \n"); 
                  break;
          }else{
                      JOptionPane.showMessageDialog(null, "Deletion cancelled.");
                  }
          
          
        
      }
     
         i++;  
      }
          //if the student ID is not found --> 'not found' message display
          if(!found){
              JOptionPane.showMessageDialog(null, "Student with student ID: " + deleteID + " " + "was not found!");
      
       }
      }
   
      //display all details of students
      public void StudentReport(){
          for (int j = 0; j < SIZE ; j++) {
            
           JOptionPane.showMessageDialog(null, "Student " + studentNum[j] + "\n"
                        + " "
                        + "STUDENT ID: " + studentID[j] + "\n"
                        + "STUDENT NAME: " + studentName[j] + "\n"
                        + "STUDENT AGE: " + studentAge[j] + "\n"
                        + "STUDENT EMAIL: " + studentEmail[j]+ "\n"
                        + "STUDENT COURSE: " + studentCourse[j]);
     }
}
      public void ExitStudentApplication()
      {
          JOptionPane.showMessageDialog(null, "Exiting Application...");  System.exit(0);
      }
      
}
/*
Reference :

stackoverflow (Multiple Input in JOptionPane.showInputDialog) -  https://stackoverflow.com/questions/6555040/multiple-input-in-joptionpane-showinputdialog
*/
 