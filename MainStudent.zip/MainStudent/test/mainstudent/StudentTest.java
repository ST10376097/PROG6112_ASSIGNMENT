/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package mainstudent;

import java.util.Arrays;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class StudentTest {
    
    public StudentTest() {
    }

    @Test
    public void testSaveStudent() {
        Student st = new Student();
        
        for (int i = 0; i < st.SIZE ; i++) {
          
                    int sID = 123;
                    String name = "Archana";
                    int age = 19;
                    String email = "archana@gmail.com";
                    String course = "BCAD";
                    
                    
               
                    
                    assertEquals(123, st.studentID);
                    assertEquals("Archana", st.studentName);
                    assertEquals(19, st.studentAge);
                    assertEquals("archana@gmail.com", st.studentEmail);
                    assertEquals("BCAD", st.studentCourse);
         }
        }
                                               
                 
 
             
         

    @Test
    public void testSearchStudent() {
        Student st = new Student();
       
           for (int i = 0; i < st.SIZE ; i++) {
            int sID = 123;
                    String name = "Archana";
                    int age = 19;
                    String email = "archana@gmail.com";
                    String course = "BCAD";   
                    
                    
                    int searchId = sID;
                    
                     if(st.studentID[i] == searchId){
              
                    assertEquals(123, st.studentID);
                    
                   JOptionPane.showMessageDialog(null, "STUDENT ID: " +st.studentID[i] + "\n"
                        + "STUDENT NAME: " + st.studentName[i] + "\n"
                        + "STUDENT AGE: " + st.studentAge[i] + "\n"
                        + "STUDENT EMAIL: " + st.studentEmail[i]+ "\n"
                        + "STUDENT COURSE: " + st.studentCourse[i]);
                   
      }
      }

    }
    
    @Test
    public void testSearchStudent_StudentNotFound() {
        
        Student st = new Student();
       boolean found = false;
           for (int i = 0; i < st.SIZE ; i++) {
            int sID = 123;
                    String name = "Archana";
                    int age = 19;
                    String email = "archana@gmail.com";
                    String course = "BCAD";   
                    
                    
                    int searchId = sID;
                     if(!found){
           {
               JOptionPane.showMessageDialog(null, "Student with student ID: " + " " + searchId + " " + "was not found!");
           }
           
       
    }
    }
   }
    
    @Test
    public void testDeleteStudent() {
        
    Student st = new Student();
     boolean found = false;
        for (int i = 0; i < st.SIZE ; i++) {
            int sID = 123;
                    String name = "Archana";
                    int age = 19;
                    String email = "archana@gmail.com";
                    String course = "BCAD";   
        
                  int delId = sID;
                    if(st.studentID[i] == delId){
                  found = true;
                  
                  
                   String confirm = JOptionPane.showInputDialog(null, "Are you sure you want to delete student " + delId + " " + "from the system? \n"
                  + "Yes --> (y) to delete.");
           
                  
                  
                  if(confirm.equals("y")){
                      
                  
                      JOptionPane.showMessageDialog(null, "Confirmed!");
                      
                    assertEquals(123, st.studentID);
                   
                  for (int j = i; j < st.studentID.length -1; j++) {
                      //shift values in each array
                      st.studentID[j] = st.studentID[j + 1];
                      st.studentName[j] = st.studentName[j + 1];
                      st.studentAge[j] = st.studentAge[j + 1];
                      st.studentEmail[j] = st.studentEmail[j + 1];
                      st.studentCourse[j] = st.studentCourse[j+1];
                      
                      
                  }
                  //removing all details of the student chosen
                  st.studentID = Arrays.copyOf(st.studentID, st.studentID.length - 1);
                  st.studentName = Arrays.copyOf(st.studentName, st.studentName.length - 1);
                  st.studentAge = Arrays.copyOf(st.studentAge, st.studentAge.length - 1);
                  st.studentEmail = Arrays.copyOf(st.studentEmail, st.studentEmail.length - 1);
                  st.studentCourse = Arrays.copyOf(st.studentCourse, st.studentCourse.length - 1);
                   
     }
    }
    }
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        Student st = new Student();
       boolean found = false;
           for (int i = 0; i < st.SIZE ; i++) {
            int sID = 123;
                    String name = "Archana";
                    int age = 19;
                    String email = "archana@gmail.com";
                    String course = "BCAD";   
                    
                    
                    int delId = sID;
                     if(!found){
        JOptionPane.showMessageDialog(null, "Student with student ID:  " + delId + " " + "was deleted! \n");
    }
           }
    }
    
    @Test
    public void testStudentReport() {
        
         Student st = new Student(); 
            st.StudentReport();
        }
    
    
    @Test
    public void testStudentAge_StudentAgeValid()
{
     
    Student st = new Student();
    for (int i = 0; i < st.SIZE; i++) {
        
    int age = 19;
        assertEquals(19, st.studentAge);
    } 
}
    
  
    @Test
    public void testStudentAge_StudentAgeInvalid()
    {
        
     Student st = new Student();
      for (int i = 0; i < st.SIZE; i++) {
        
        
         while(st.studentAge[i] < 16){
                st.studentAge[i] = Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                                    \t\t <<<You have entered an incorrect student age!!>>> 
                                                                                     
                                                                                       please re-enter the student age >>"""));
    }
    
  } 
    }
}

